<?php
session_start();
date_default_timezone_set('America/Bogota'); 
include "conexion.php";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Verificar sesión
if (!isset($_SESSION['usuario']) || !in_array($_SESSION['rol'], ['empleado', 'admin'])) {
    header("Location: login.php");
    exit;
}

// Recibir datos del formulario
$correo        = $_POST['correo'] ?? '';
$producto_raw  = $_POST['producto_aceite'] ?? ''; // Formato: producto|tipo|precio_unitario
$tipo_carro    = $_POST['tipo_carro'] ?? '';
$placa         = $_POST['placa'] ?? '';
$cantidad      = intval($_POST['cantidad'] ?? 0);
$precio_total  = floatval($_POST['precio'] ?? 0);
$metodo_pago   = $_POST['metodo_pago'] ?? '';
$pago_cliente  = floatval($_POST['pago_cliente'] ?? 0);
$fecha         = $_POST['fecha'] ?? date("Y-m-d");
$hora          = date("H:i:s");

// Extraer producto, tipo y precio unitario
list($producto, $aceite, $precio_unitario) = explode('|', $producto_raw);

// Calcular cambio solo si método es efectivo
$cambio = 0;
if ($metodo_pago === "Efectivo") {
    if ($pago_cliente < $precio_total) {
        echo "<script>alert('Verifica los campos. El pago debe ser mayor o igual al total.'); window.location='../empleado.php?seccion=facturacion';</script>";
        exit;
    }
    $cambio = $pago_cliente - $precio_total;
} else {
    $pago_cliente = $precio_total;
}

// Validación
if (
    empty($correo) || empty($producto) || empty($tipo_carro) || empty($placa) || empty($aceite) ||
    $cantidad <= 0 || $precio_total <= 0
) {
    echo "<script>alert('Campos obligatorios incompletos.'); window.location='../empleado.php?seccion=facturacion';</script>";
    exit;
}

// Verificar existencia en inventario
$verificar = $conn->prepare("SELECT cantidad FROM inventario WHERE producto = ? AND tipo = ? AND cantidad >= ?");
$verificar->bind_param("ssi", $producto, $aceite, $cantidad);
$verificar->execute();
$res = $verificar->get_result();
if ($res->num_rows === 0) {
    echo "<script>alert('No hay suficiente inventario para este producto.'); window.location='../empleado.php?seccion=facturacion';</script>";
    exit;
}

// Insertar en facturas
$sql = "INSERT INTO facturas 
        (correo, tipo_carro, placa, aceite, cantidad, total, pago_cliente, cambio, fecha) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssiddds", $correo, $tipo_carro, $placa, $aceite, $cantidad, $precio_total, $pago_cliente, $cambio, $fecha);
$registrado = $stmt->execute();

if ($registrado) {
    // Registrar también la venta
    $empleado = $_SESSION['usuario']; // nombre del empleado que hizo la venta

    $sql_venta = "INSERT INTO ventas 
                  (producto, tipo, cantidad_vendida, precio, total, fecha, hora, metodo_pago, empleado) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_venta = $conn->prepare($sql_venta);
    $stmt_venta->bind_param("ssidsssss", $producto, $aceite, $cantidad, $precio_unitario, $precio_total, $fecha, $hora, $metodo_pago, $empleado);
    $stmt_venta->execute(); // ← esta línea era la que faltaba

    // Actualizar inventario
    $sql_update = "UPDATE inventario 
                   SET cantidad = cantidad - ? 
                   WHERE producto = ? AND tipo = ? AND cantidad >= ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("issi", $cantidad, $producto, $aceite, $cantidad);
    $stmt_update->execute();

    // Redireccionar según el rol
    $redireccion = ($_SESSION['rol'] === 'admin') ? '../admin.php?seccion=facturacion' : '../empleado.php?seccion=facturacion';
    echo "<script>alert('Factura registrada exitosamente.'); window.location='$redireccion';</script>";
} else {
    echo "<script>alert('Error al guardar la factura.'); window.location='../empleado.php?seccion=facturacion';</script>";
}
?>






