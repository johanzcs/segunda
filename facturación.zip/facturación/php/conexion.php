<?php
$host = "localhost";
$usuario = "root";
$contrasena = ""; // déjalo vacío si no tienes clave
$basedatos = "aceicar"; // ← tu base de datos real aquí

$conn = new mysqli($host, $usuario, $contrasena, $basedatos);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>



