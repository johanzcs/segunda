<?php
include "conexion.php";
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Eliminar si se pasó el parámetro por GET
if (isset($_GET['eliminar'])) {
    $idEliminar = intval($_GET['eliminar']);

    $conn->query("DELETE FROM facturas WHERE id = $idEliminar");

    // Redirigir para limpiar la URL y recargar la tabla
     header("Location: http://localhost/facturación/admin.php?seccion=editar_factura");

    exit;
}

// Obtener las facturas
$facturas = $conn->query("SELECT * FROM facturas ORDER BY fecha DESC, id DESC");
?>

<h2 style="color:#e30613; text-align:center;">Editar / Eliminar Facturas</h2>

<table border="1" cellpadding="10" cellspacing="0" style="width:100%; background:#1a1a1a; color:white; border-collapse:collapse;">
  <tr style="background:#e30613;">
    <th>ID</th>
    <th>Cliente</th>
    <th>Carro</th>
    <th>Placa</th>
    <th>Producto</th>
    <th>Cantidad</th>
    <th>Total</th>
    <th>Pago</th>
    <th>Cambio</th>
    <th>Fecha</th>
    <th>Acciones</th>
  </tr>
  <?php while ($f = $facturas->fetch_assoc()): ?>
  <tr>
    <td><?= $f['id'] ?></td>
    <td><?= $f['correo'] ?></td>
    <td><?= $f['tipo_carro'] ?></td>
    <td><?= $f['placa'] ?></td>
    <td><?= $f['aceite'] ?></td>
    <td><?= $f['cantidad'] ?></td>
    <td>$<?= number_format($f['total'], 0, ',', '.') ?></td>
    <td>$<?= number_format($f['pago_cliente'], 0, ',', '.') ?></td>
    <td>$<?= number_format($f['cambio'], 0, ',', '.') ?></td>
    <td><?= $f['fecha'] ?></td>
    <td>
      <a href="?seccion=editar_factura&eliminar=<?= $f['id'] ?>" onclick="return confirm('¿Seguro que deseas eliminar esta factura?')" style="color:#e30613;">🗑 Eliminar</a>
    </td>
  </tr>
  <?php endwhile; ?>
</table>
